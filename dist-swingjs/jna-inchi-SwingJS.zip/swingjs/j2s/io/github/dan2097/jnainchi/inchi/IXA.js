(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi.inchi"),I$=[[0,'com.sun.jna.Pointer','io.github.dan2097.jnainchi.inchi.InchiLibrary']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IXA");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['ATOM_IMPLICIT_H','com.sun.jna.Pointer']]]

Clazz.newMeth(C$, 'IXA_STATUS_Create$',  function () {
return $I$(2).IXA_STATUS_Create$();
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_Clear$com_sun_jna_Pointer',  function (hStatus) {
$I$(2).IXA_STATUS_Clear$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_Destroy$com_sun_jna_Pointer',  function (hStatus) {
$I$(2).IXA_STATUS_Destroy$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_HasError$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_STATUS_HasError$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_HasWarning$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_STATUS_HasWarning$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetCount$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_STATUS_GetCount$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetSeverity$com_sun_jna_Pointer$I',  function (hStatus, vIndex) {
return $I$(2).IXA_STATUS_GetSeverity$com_sun_jna_Pointer$I(hStatus, vIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_STATUS_GetMessage$com_sun_jna_Pointer$I',  function (hStatus, vIndex) {
return $I$(2).IXA_STATUS_GetMessage$com_sun_jna_Pointer$I(hStatus, vIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Create$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_MOL_Create$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Clear$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
$I$(2).IXA_MOL_Clear$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
$I$(2).IXA_MOL_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$S',  function (hStatus, hMolecule, pBytes) {
$I$(2,"IXA_MOL_ReadMolfile$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus, hMolecule, C$.fromString$S(pBytes)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$S',  function (hStatus, hMolecule, pInChI) {
$I$(2,"IXA_MOL_ReadInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus, hMolecule, C$.fromString$S(pInChI)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z',  function (hStatus, hMolecule, vChiral) {
$I$(2).IXA_MOL_SetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer$Z(hStatus, hMolecule, vChiral);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
return $I$(2).IXA_MOL_GetChiral$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateAtom$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
return $I$(2).IXA_MOL_CreateAtom$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$S',  function (hStatus, hMolecule, vAtom, pElement) {
$I$(2,"IXA_MOL_SetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus, hMolecule, vAtom, C$.fromString$S(pElement)]);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vAtomicNumber) {
$I$(2).IXA_MOL_SetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vAtomicNumber);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vMassNumber) {
$I$(2).IXA_MOL_SetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vMassNumber);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vCharge) {
$I$(2).IXA_MOL_SetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vCharge);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vRadical) {
$I$(2).IXA_MOL_SetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vRadical);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber, vHydrogenCount) {
$I$(2).IXA_MOL_SetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I(hStatus, hMolecule, vAtom, vHydrogenMassNumber, vHydrogenCount);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vX) {
$I$(2).IXA_MOL_SetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, vX);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vY) {
$I$(2).IXA_MOL_SetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, vY);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D',  function (hStatus, hMolecule, vAtom, vZ) {
$I$(2).IXA_MOL_SetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$D(hStatus, hMolecule, vAtom, vZ);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom1, vAtom2) {
return $I$(2).IXA_MOL_CreateBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom1, vAtom2);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vType) {
$I$(2).IXA_MOL_SetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vType);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vRefAtom, vDirection) {
$I$(2).IXA_MOL_SetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vRefAtom, vDirection);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBond, vConfig) {
$I$(2).IXA_MOL_SetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBond, vConfig);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoTetrahedron$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
return $I$(2).IXA_MOL_CreateStereoTetrahedron$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralBond, vVertex1, vVertex2, vVertex3, vVertex4) {
return $I$(2).IXA_MOL_CreateStereoRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralBond, vVertex1, vVertex2, vVertex3, vVertex4);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_CreateStereoAntiRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4) {
return $I$(2).IXA_MOL_CreateStereoAntiRectangle$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vCentralAtom, vVertex1, vVertex2, vVertex3, vVertex4);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_SetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereo, vParity) {
$I$(2).IXA_MOL_SetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vStereo, vParity);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_ReserveSpace$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I$I',  function (hStatus, hMolecule, num_atoms, num_bonds, num_stereos) {
return $I$(2).IXA_MOL_ReserveSpace$com_sun_jna_Pointer$com_sun_jna_Pointer$I$I$I(hStatus, hMolecule, num_atoms, num_bonds, num_stereos);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
return $I$(2).IXA_MOL_GetNumAtoms$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
return $I$(2).IXA_MOL_GetNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtomIndex) {
return $I$(2).IXA_MOL_GetAtomId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtomIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vBondIndex) {
return $I$(2).IXA_MOL_GetBondId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vBondIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
return $I$(2).IXA_MOL_GetBondIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomNumBonds$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vBondIndex) {
return $I$(2).IXA_MOL_GetAtomBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vBondIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetCommonBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom1, vAtom2) {
return $I$(2).IXA_MOL_GetCommonBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom1, vAtom2);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
return $I$(2).IXA_MOL_GetBondAtom1$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
return $I$(2).IXA_MOL_GetBondAtom2$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondOtherAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond, vAtom) {
return $I$(2).IXA_MOL_GetBondOtherAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomElement$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomAtomicNumber$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomMass$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomCharge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomRadical$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vAtom, vHydrogenMassNumber) {
return $I$(2).IXA_MOL_GetAtomHydrogens$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vAtom, vHydrogenMassNumber);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomX$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomY$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vAtom) {
return $I$(2).IXA_MOL_GetAtomZ$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
return $I$(2).IXA_MOL_GetBondType$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond, vRefAtom) {
return $I$(2).IXA_MOL_GetBondWedge$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond, vRefAtom);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vBond) {
return $I$(2).IXA_MOL_GetDblBondConfig$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vBond);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetNumStereos$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule) {
return $I$(2).IXA_MOL_GetNumStereos$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoId$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereoIndex) {
return $I$(2).IXA_MOL_GetStereoId$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vStereoIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoIndex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoTopology$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoTopology$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoCentralAtom$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoCentralBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoCentralBond$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoNumVertices$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoNumVertices$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoVertex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hMolecule, vStereo, vVertexIndex) {
return $I$(2).IXA_MOL_GetStereoVertex$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hMolecule, vStereo, vVertexIndex);
}, 1);

Clazz.newMeth(C$, 'IXA_MOL_GetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hMolecule, vStereo) {
return $I$(2).IXA_MOL_GetStereoParity$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hMolecule, vStereo);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Create$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_INCHIBUILDER_Create$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetMolecule$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder, hMolecule) {
$I$(2).IXA_INCHIBUILDER_SetMolecule$com_sun_jna_Pointer$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIBuilder, hMolecule);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
return $I$(2).IXA_INCHIBUILDER_GetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetInChIEx$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hBuilder) {
return $I$(2).IXA_INCHIBUILDER_GetInChIEx$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetAuxInfo$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
return $I$(2).IXA_INCHIBUILDER_GetAuxInfo$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_GetLog$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
return $I$(2).IXA_INCHIBUILDER_GetLog$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIBuilder) {
$I$(2).IXA_INCHIBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z',  function (hStatus, hInChIBuilder, vOption, vValue) {
$I$(2).IXA_INCHIBUILDER_SetOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I$Z(hStatus, hInChIBuilder, vOption, vValue);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
$I$(2).IXA_INCHIBUILDER_SetOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hInChIBuilder, vValue);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
$I$(2).IXA_INCHIBUILDER_SetOption_Timeout$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hInChIBuilder, vValue);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$com_sun_jna_Pointer$com_sun_jna_Pointer$J',  function (hStatus, hInChIBuilder, vValue) {
$I$(2).IXA_INCHIBUILDER_SetOption_Timeout_MilliSeconds$com_sun_jna_Pointer$com_sun_jna_Pointer$J(hStatus, hInChIBuilder, vValue);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vOption) {
return $I$(2).IXA_INCHIBUILDER_CheckOption$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hInChIBuilder, vOption);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIBUILDER_CheckOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I',  function (hStatus, hInChIBuilder, vValue) {
return $I$(2).IXA_INCHIBUILDER_CheckOption_Stereo$com_sun_jna_Pointer$com_sun_jna_Pointer$I(hStatus, hInChIBuilder, vValue);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Create$com_sun_jna_Pointer',  function (hStatus) {
return $I$(2).IXA_INCHIKEYBUILDER_Create$com_sun_jna_Pointer(hStatus);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_SetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$S',  function (hStatus, hInChIKeyBuilder, pInChI) {
$I$(2,"IXA_INCHIKEYBUILDER_SetInChI$com_sun_jna_Pointer$com_sun_jna_Pointer$BA",[hStatus, hInChIKeyBuilder, C$.fromString$S(pInChI)]);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_GetInChIKey$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIKeyBuilder) {
return $I$(2).IXA_INCHIKEYBUILDER_GetInChIKey$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIKeyBuilder);
}, 1);

Clazz.newMeth(C$, 'IXA_INCHIKEYBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer',  function (hStatus, hInChIKeyBuilder) {
$I$(2).IXA_INCHIKEYBUILDER_Destroy$com_sun_jna_Pointer$com_sun_jna_Pointer(hStatus, hInChIKeyBuilder);
}, 1);

Clazz.newMeth(C$, 'fromString$S',  function (jstr) {
{
return jstr
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.ATOM_IMPLICIT_H=$I$(1,"createConstant$J",[(Long.$neg(1))]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-19 18:08:00 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
