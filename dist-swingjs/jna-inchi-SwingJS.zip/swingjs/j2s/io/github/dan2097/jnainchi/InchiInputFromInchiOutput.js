(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InchiInputFromInchiOutput");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['message','log'],'O',['inchiInput','io.github.dan2097.jnainchi.InchiInput','status','io.github.dan2097.jnainchi.InchiStatus','warningFlags','long[][]']]]

Clazz.newMeth(C$, 'c$$io_github_dan2097_jnainchi_InchiInput$S$S$io_github_dan2097_jnainchi_InchiStatus$JAA',  function (inchiInput, message, log, status, warningFlags) {
;C$.$init$.apply(this);
this.inchiInput=inchiInput;
this.message=message;
this.log=log;
this.status=status;
this.warningFlags=warningFlags;
}, 1);

Clazz.newMeth(C$, 'getInchiInput$',  function () {
return this.inchiInput;
});

Clazz.newMeth(C$, 'getMessage$',  function () {
return this.message;
});

Clazz.newMeth(C$, 'getLog$',  function () {
return this.log;
});

Clazz.newMeth(C$, 'getStatus$',  function () {
return this.status;
});

Clazz.newMeth(C$, 'getWarningFlags$',  function () {
return this.warningFlags;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-19 18:08:00 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
