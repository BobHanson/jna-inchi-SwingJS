(function(){var P$=Clazz.newPackage("io.github.dan2097.jnainchi"),I$=[[0,'java.util.ArrayList','java.util.Collections']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InchiInput");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.atoms=Clazz.new_($I$(1,1));
this.bonds=Clazz.new_($I$(1,1));
this.stereos=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['atoms','java.util.List','+bonds','+stereos']]]

Clazz.newMeth(C$, 'addAtom$io_github_dan2097_jnainchi_InchiAtom',  function (atom) {
this.atoms.add$O(atom);
});

Clazz.newMeth(C$, 'addBond$io_github_dan2097_jnainchi_InchiBond',  function (bond) {
this.bonds.add$O(bond);
});

Clazz.newMeth(C$, 'addStereo$io_github_dan2097_jnainchi_InchiStereo',  function (stereo) {
this.stereos.add$O(stereo);
});

Clazz.newMeth(C$, 'getAtom$I',  function (i) {
return this.atoms.get$I(i);
});

Clazz.newMeth(C$, 'getBond$I',  function (i) {
return this.bonds.get$I(i);
});

Clazz.newMeth(C$, 'getAtoms$',  function () {
return $I$(2).unmodifiableList$java_util_List(this.atoms);
});

Clazz.newMeth(C$, 'getBonds$',  function () {
return $I$(2).unmodifiableList$java_util_List(this.bonds);
});

Clazz.newMeth(C$, 'getStereos$',  function () {
return $I$(2).unmodifiableList$java_util_List(this.stereos);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-19 18:08:00 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
