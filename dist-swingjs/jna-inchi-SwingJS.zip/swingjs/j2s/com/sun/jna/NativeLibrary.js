(function(){var P$=Clazz.newPackage("com.sun.jna"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NativeLibrary");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name']]
,['O',['map','java.util.Map']]]

Clazz.newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz.newMeth(C$, 'getInstance$S',  function (name) {
var instance=C$.map.get$O(name);
if (instance == null ) C$.map.put$O$O(name, instance=Clazz.new_(C$.c$$S,[name]));
return instance;
}, 1);

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

C$.$static$=function(){C$.$static$=0;
C$.map=Clazz.new_($I$(1,1));
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-18 12:03:16 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
