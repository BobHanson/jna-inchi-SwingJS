(function(){var P$=Clazz.newPackage("com.sun.jna"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Native");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'register$Class$com_sun_jna_NativeLibrary',  function (clazz, library) {
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-18 12:03:16 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
